package uk.ac.shef.planar.alias

typealias PlanarDataset = uk.ac.shef.planar.Dataset
typealias PlanarDimensionDescription = uk.ac.shef.planar.DimensionDescription
typealias PlanarDescription = uk.ac.shef.planar.Description
typealias PlanarCoordinate = uk.ac.shef.planar.Coordinate

